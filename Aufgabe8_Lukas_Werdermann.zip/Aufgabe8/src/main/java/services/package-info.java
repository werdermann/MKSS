@ModuleGen(name = "services", groupPackage = "services")
package services;

import io.vertx.codegen.annotations.ModuleGen;
